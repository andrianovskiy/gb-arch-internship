package com.arch.intern.crm.backend.requests.model.enums;

public enum RequestStatusType {

    OPEN,
    IN_PROGRESS,
    DONE,
    CLOSED;
}
