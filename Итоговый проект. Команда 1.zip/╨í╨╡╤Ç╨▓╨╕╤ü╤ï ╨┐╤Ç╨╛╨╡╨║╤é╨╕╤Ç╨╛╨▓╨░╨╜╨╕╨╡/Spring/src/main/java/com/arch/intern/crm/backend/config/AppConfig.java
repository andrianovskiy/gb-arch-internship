package com.arch.intern.crm.backend.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;



/**
 * @author Marchenko_DS in 25/04/2022
 */
@Configuration
public class AppConfig {

}
