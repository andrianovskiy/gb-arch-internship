package com.arch.intern.crm.backend.board.model.enums;


import lombok.ToString;

@ToString
public enum BoardType {
    TASK,
    REQUEST,
    ORDER;
}
