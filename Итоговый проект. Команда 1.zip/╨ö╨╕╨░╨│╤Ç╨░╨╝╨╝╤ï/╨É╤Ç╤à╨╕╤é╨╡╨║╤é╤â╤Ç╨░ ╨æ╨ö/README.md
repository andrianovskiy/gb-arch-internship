### Пример реверсинженерига 

 - Накатываем базу из файла или поднимаем контейнер с приложением
   docker pull daniakacta/arch-intern
 - Ставим
   https://dbeaver.io/
 - подключаемся к тестовой базе postgres://jxwzhxhe:RGuzwB10YGPHwj3n_qqiTEKFY4V1oSEj@isilo.db.elephantsql.com/jxwzhxhe
   https://api.elephantsql.com
 - жмахаем на схему -> view diagram 